﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Mapping_one_to_Many.Migrations
{
    /// <inheritdoc />
    public partial class empmigration : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
