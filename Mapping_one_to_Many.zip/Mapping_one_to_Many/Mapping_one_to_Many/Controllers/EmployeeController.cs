﻿using Mapping_one_to_Many.Data;
using Mapping_one_to_Many.DTO;
using Mapping_one_to_Many.Model.Entity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Mapping_one_to_Many.Controllers
{
    public class EmployeeController : Controller

    {
        private readonly ApplicationDBContext dBContext;
        public EmployeeController(ApplicationDBContext dbcontext)
        {
            this.dBContext = dbcontext;
        }
        [HttpGet]
        [Route("Get/employee")]
        public async Task<ActionResult> GetEmployees()
        {
            var employees = await dBContext.employees
                .Include(e => e.Addresses)
                .Select(e => new EmployeeDto()
                {
                    EmployeeId = e.EmployeeId,
                    Name = e.Name,
                    Addresses = e.Addresses.Select(a => new AddressDto
                    {
                        AddressId = a.AddressId,
                        Street = a.Street,
                        City = a.City,
                        EmployeeId = a.EmployeeId
                    })
                }).ToListAsync();

            return Ok(employees);
        }

        [HttpPost]
        [Route("add/EmployeeAdress")]
        public IActionResult AddEmployeeAddress([FromBody] EmployeeDto employeeDto)
        {
            var employeeEntity = new Employee
            {
                name = employeeDto.name,
                Email = employeeDto.Email,
                phone = employeeDto.phone,
                salary = employeeDto.salary,
                Addresses = new Address
                {
                    street_address = employeeDto.street_address,
                    city = employeeDto.city,
                    state = employeeDto.state,
                    zip_code = addemployeedto.zip_code,
                    country = addemployeedto.country,
                   
                    
                }
                


            };
            dBContext.Add(employeeEntity);
            dBContext.SaveChanges();
            return Ok(employeeEntity);
        }
    }
}
