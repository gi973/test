﻿namespace Mapping_one_to_Many.DTO
{
    public class EmployeeDto
    {
        public required string name { get; set; }
        public required string Email { get; set; }
        public string? phone { get; set; }
        public decimal salary { get; set; }
        public List<AddressDto> Addresses { get; set; }
    }
}
