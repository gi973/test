﻿using System.ComponentModel.DataAnnotations;

namespace Mapping_one_to_Many.Model.Entity
{
    public class Employee
    {
        [Key]
        public int Id { get; set; }
        public required string name { get; set; }
        public required string Email { get; set; }
        public string? phone { get; set; }
        public decimal salary { get; set; }

        public int AddressId { get; set; } // Foreign key for the navigation property.
        public ICollection<Address> Addresses { get; set; }

    }
}
