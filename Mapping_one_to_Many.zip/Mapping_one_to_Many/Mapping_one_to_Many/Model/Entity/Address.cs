﻿using System.ComponentModel.DataAnnotations;

namespace Mapping_one_to_Many.Model.Entity
{
    public class Address
    {
        [Key]
        public int Id { get; set; }
        public string street_address { get; set; }
        public string city { get; set; }
        public string state { get; set; }
        public string zip_code { get; set; }
        public string country { get; set; }


        public int EmployeeId { get; set; }
        public Employee Employee { get; set; }


    }
}
